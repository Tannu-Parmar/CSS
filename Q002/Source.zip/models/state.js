const mongoose = require('mongoose');

const stateSchema = new mongoose.Schema({
    stateID: String,
    Name: String,
    City: String,
});

export const stateModel = mongoose.model("state", stateSchema);