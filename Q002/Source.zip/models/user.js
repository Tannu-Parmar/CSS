const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    userID: String,
    Name: String,
    Password: String,
    DOB: Number,
    DOJ: Number,
    PanCard: String,
    City: String,
    stateid: String,
    cityid: String,
    ReportingHead: String,
});
export const userModel = mongoose.model("user", userSchema);