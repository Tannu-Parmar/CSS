const express = require('express')
const mongoose = require('mongoose')

mongoose.connect("mongodb://localhost:27017/q2")
    .then(() => console.log("Database connected.."))
    .catch(() => console.log("error"));

